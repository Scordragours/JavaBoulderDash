create procedure HelloworldByCode(IN p_code varchar(2))
  SELECT * FROM jpublankproject.helloworld where `code`=p_code;

