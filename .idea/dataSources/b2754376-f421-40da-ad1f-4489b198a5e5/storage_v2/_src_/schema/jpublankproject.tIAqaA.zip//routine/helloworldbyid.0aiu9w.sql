create procedure helloworldById(IN p_id int)
  SELECT * FROM helloworld WHERE id = p_id;

